package com.cg.tripPlanner.exception;

public class TripPlannerException extends Exception {
	
public TripPlannerException(String message) {
	super(message);
}
}
